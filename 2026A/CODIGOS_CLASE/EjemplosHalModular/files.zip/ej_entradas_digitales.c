/*
 * ej_entradas_digitales.c
 *
 * Aplicacion: Entradas digitales — botones, switches y DIP switch
 * Modulo HAL: gpio.h
 * Target:     ATmega328P / ATmega1284P
 *
 * Circuito:
 *   PD2 -> boton momentaneo A (pull-up interno, a GND al presionar)
 *   PD3 -> boton momentaneo B (pull-up interno, a GND al presionar)
 *   PC0..PC3 -> DIP switch de 4 posiciones (pull-up interno, a GND cuando ON)
 *   PB0..PB3 -> LEDs de salida (220 ohm a GND)
 *   PB4      -> LED indicador de modo
 *
 * -------------------------------------------------------
 * CONCEPTO CLAVE: Pull-up interno y logica negada
 * -------------------------------------------------------
 * Con pull-up activado:
 *   Pin sin presionar -> HIGH (5V, el pull-up lo mantiene arriba)
 *   Pin presionado    -> LOW  (0V, el boton conecta a GND)
 *
 * Esto se llama "logica negada" o "active low":
 *   Leer HIGH significa "no presionado"
 *   Leer LOW  significa "presionado"
 *
 * Ventaja: no necesitas resistencias externas.
 * El AVR tiene pull-ups internos de ~50kOhm.
 * -------------------------------------------------------
 *
 * -------------------------------------------------------
 * CONCEPTO CLAVE: Debounce (antirrebote)
 * -------------------------------------------------------
 * Los botones mecanicos "rebotan" al presionarse:
 * en lugar de un solo flanco limpio, generan multiples
 * transiciones en ~5-20ms. Sin debounce, una sola
 * presion puede registrarse como 10 o mas.
 *
 * Solucion simple por software: leer el pin, esperar
 * 20ms, y leer de nuevo. Si ambas lecturas coinciden,
 * es una presion real.
 * -------------------------------------------------------
 */

#include <util/delay.h>
#include "gpio.h"

#define DEBOUNCE_MS   20U   /* tiempo de antirrebote */

/* Pines de botones */
#define BTN_A_PIN   2U
#define BTN_B_PIN   3U

/* =========================================
   FUNCIONES DE LECTURA CON DEBOUNCE
   ========================================= */

/*
 * boton_presionado
 * -----------------
 * Lee un pin con debounce por software.
 * Retorna 1 si el boton esta presionado, 0 si no.
 *
 * Como el boton es active-low:
 *   GPIO_READ_PORTD(pin) == LOW  significa presionado
 */
static uint8_t boton_presionado(uint8_t pin)
{
    /* Primera lectura */
    if (GPIO_READ_PORTD(pin) == LOW) {
        /* Esperar el tiempo de rebote */
        _delay_ms(DEBOUNCE_MS);
        /* Segunda lectura — confirmar */
        if (GPIO_READ_PORTD(pin) == LOW) {
            return 1U;
        }
    }
    return 0U;
}

/*
 * esperar_soltar
 * ---------------
 * Espera hasta que el boton sea soltado.
 * Util para detectar "una presion" en lugar de
 * "mantener presionado" (detecta flanco de bajada).
 */
static void esperar_soltar(uint8_t pin)
{
    while (GPIO_READ_PORTD(pin) == LOW) {
        _delay_ms(DEBOUNCE_MS);
    }
}

/* =========================================
   EJEMPLO 1: LED sigue al boton
   Mientras A presionado -> LED ON
   ========================================= */
static void demo_led_directo(void)
{
    uint16_t ciclos = 0U;
    while (ciclos < 500U) {    /* ~5 segundos */
        if (GPIO_READ_PORTD(BTN_A_PIN) == LOW) {
            GPIO_WRITE_PORTB(0, HIGH);   /* LED ON  */
        } else {
            GPIO_WRITE_PORTB(0, LOW);    /* LED OFF */
        }
        _delay_ms(10);
        ciclos++;
    }
}

/* =========================================
   EJEMPLO 2: Toggle — cada presion cambia el LED
   ========================================= */
static void demo_toggle(void)
{
    uint8_t estado_led = 0U;
    uint16_t ciclos = 0U;

    while (ciclos < 2000U) {
        if (boton_presionado(BTN_A_PIN)) {
            estado_led = (estado_led == 0U) ? 1U : 0U;
            GPIO_WRITE_PORTB(1, estado_led);
            esperar_soltar(BTN_A_PIN);
        }
        _delay_ms(10);
        ciclos++;
    }
}

/* =========================================
   EJEMPLO 3: Contador con dos botones
   Boton A = incrementar, Boton B = decrementar
   Resultado se muestra en PB0..PB3 (4 LEDs en binario)
   ========================================= */
static void demo_contador_botones(void)
{
    uint8_t contador = 0U;
    uint16_t ciclos = 0U;

    /* Mostrar valor inicial */
    GPIO_PORT_WRITE_B(contador & 0x0FU);

    while (ciclos < 3000U) {
        if (boton_presionado(BTN_A_PIN)) {
            if (contador < 15U) contador++;
            GPIO_PORT_WRITE_B(contador & 0x0FU);
            esperar_soltar(BTN_A_PIN);
        }

        if (boton_presionado(BTN_B_PIN)) {
            if (contador > 0U) contador--;
            GPIO_PORT_WRITE_B(contador & 0x0FU);
            esperar_soltar(BTN_B_PIN);
        }

        _delay_ms(10);
        ciclos++;
    }
}

/* =========================================
   EJEMPLO 4: DIP switch -> LEDs
   Los 4 switches controlan los 4 LEDs directamente
   Lee el puerto C completo y lo muestra en puerto B
   ========================================= */
static void demo_dip_switch(void)
{
    uint16_t ciclos = 0U;

    while (ciclos < 2000U) {
        /*
         * Leer los 4 bits bajos de PORTC (DIP switch).
         * Como son active-low, invertimos con XOR 0x0F
         * para que switch ON = LED ON.
         */
        uint8_t estado_dip = GPIO_PORT_READ_C() & 0x0FU;
        uint8_t leds = (uint8_t)(estado_dip ^ 0x0FU);  /* invertir logica */
        GPIO_PORT_WRITE_B(leds);

        _delay_ms(50);
        ciclos++;
    }
}

int main(void)
{
    /* Configurar salidas: PB0..PB4 */
    GPIO_PORT_MODE_B(0x1FU);    /* 0001 1111 = PB0..PB4 como OUTPUT */
    GPIO_PORT_WRITE_B(0x00U);

    /* Configurar entradas con pull-up: PD2, PD3 (botones) */
    GPIO_PIN_MODE_PORTD(BTN_A_PIN, INPUT);
    GPIO_PIN_MODE_PORTD(BTN_B_PIN, INPUT);
    GPIO_PULLUP_PORTD(BTN_A_PIN, 1U);   /* activar pull-up */
    GPIO_PULLUP_PORTD(BTN_B_PIN, 1U);

    /* Configurar entradas con pull-up: PC0..PC3 (DIP switch) */
    GPIO_PIN_MODE_PORTC(0, INPUT); GPIO_PULLUP_PORTC(0, 1U);
    GPIO_PIN_MODE_PORTC(1, INPUT); GPIO_PULLUP_PORTC(1, 1U);
    GPIO_PIN_MODE_PORTC(2, INPUT); GPIO_PULLUP_PORTC(2, 1U);
    GPIO_PIN_MODE_PORTC(3, INPUT); GPIO_PULLUP_PORTC(3, 1U);

    while (1)
    {
        /* Indicador de demo activa: PB4 ON */
        GPIO_WRITE_PORTB(4, HIGH);

        demo_led_directo();
        demo_toggle();
        demo_contador_botones();
        demo_dip_switch();

        GPIO_PORT_WRITE_B(0x00U);
        _delay_ms(500);
    }

    return 0;
}

/*
 * -------------------------------------------------------
 * PREGUNTAS DE REFLEXION
 * -------------------------------------------------------
 * 1. Que es el "rebote" de un boton? Por que ocurre
 *    fisicamente? Dibuja como se ve la señal sin y con
 *    debounce en un osciloscopio.
 *
 * 2. En demo_dip_switch(), por que se usa XOR con 0x0F
 *    para invertir la logica? Que valor da XOR(0b1010, 0b1111)?
 *
 * 3. Por que esperar_soltar() es necesaria en demo_toggle()?
 *    Que pasaria sin ella si el usuario mantiene presionado
 *    el boton durante 200ms?
 *
 * 4. DESAFIO: Implementa un boton con deteccion de
 *    "presion larga" (>1 segundo) vs "presion corta"
 *    (<1 segundo). Presion corta = incrementar contador,
 *    presion larga = resetear a cero.
 * -------------------------------------------------------
 */
