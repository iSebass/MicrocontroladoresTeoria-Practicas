/*
 * ej_matriz_leds.c
 *
 * Aplicacion: Matriz de LEDs 8x8 con Puerto completo
 * Modulo HAL: gpio.h
 * Target:     ATmega328P / ATmega1284P
 *
 * Circuito:
 *   PORTD (PD0..PD7) -> columnas de la matriz (catodos)
 *   PORTB (PB0..PB7) -> filas de la matriz    (anodos)
 *   Sin resistencias adicionales si se usa corriente <20mA por LED
 *   (con resistencias de 100 ohm en cada fila es mas seguro)
 *
 * -------------------------------------------------------
 * CONCEPTO CLAVE: Matriz de LEDs y scan de filas
 * -------------------------------------------------------
 * Una matriz 8x8 tiene 64 LEDs pero solo necesita 16 pines
 * (8 filas + 8 columnas) en lugar de 64.
 *
 * Para encender el LED [fila=2, col=5]:
 *   Fila 2  -> HIGH (anodo)
 *   Col  5  -> LOW  (catodo)
 *   Todos los demas: fila=LOW o col=HIGH
 *
 * Para mostrar una imagen completa se hace scan de filas:
 *   activar fila 0 + patrones de columnas -> 1ms
 *   activar fila 1 + patrones de columnas -> 1ms
 *   ... (8 filas x 1ms = 8ms por frame = 125 FPS)
 * -------------------------------------------------------
 */

#include <util/delay.h>
#include "gpio.h"

#define FILAS      8U
#define COLS       8U
#define FRAME_MS   1U    /* tiempo por fila en el scan */

/*
 * Framebuffer: cada byte representa una fila.
 * Bit 0 = columna 0 (izquierda), Bit 7 = columna 7 (derecha)
 * 1 = LED ON, 0 = LED OFF
 */
static uint8_t framebuf[FILAS];

/*
 * matriz_scan
 * ------------
 * Refresca la matriz una vez (recorre las 8 filas).
 * Duracion total: 8 * FRAME_MS = 8ms.
 */
static void matriz_scan(void)
{
    uint8_t fila;
    for (fila = 0U; fila < FILAS; fila++) {
        /* Apagar todas las filas */
        GPIO_PORT_WRITE_B(0x00U);

        /*
         * Cargar patron de columnas para esta fila.
         * Las columnas son catodos: 0=LED ON, 1=LED OFF
         * Invertimos el framebuffer con XOR 0xFF
         */
        GPIO_PORT_WRITE_D((uint8_t)(~framebuf[fila]));

        /* Activar solo la fila activa */
        GPIO_PORT_WRITE_B((uint8_t)(1U << fila));

        _delay_ms(FRAME_MS);
    }
    GPIO_PORT_WRITE_B(0x00U);
}

/*
 * matriz_clear / matriz_fill
 * ---------------------------
 * Limpiar o llenar el framebuffer completo.
 */
static void matriz_clear(void)
{
    uint8_t i;
    for (i = 0U; i < FILAS; i++) framebuf[i] = 0x00U;
}

static void matriz_fill(void)
{
    uint8_t i;
    for (i = 0U; i < FILAS; i++) framebuf[i] = 0xFFU;
}

/*
 * matriz_set_pixel
 * -----------------
 * Enciende o apaga un pixel individual.
 */
static void matriz_set_pixel(uint8_t fila, uint8_t col, uint8_t on)
{
    if (fila >= FILAS || col >= COLS) return;
    if (on) {
        framebuf[fila] |=  (uint8_t)(1U << col);
    } else {
        framebuf[fila] &= (uint8_t)(~(1U << col));
    }
}

/*
 * Patrones predefinidos (8 bytes = 8 filas)
 * Cada byte = patron de columnas de esa fila
 */

/* Cara feliz */
static const uint8_t PATRON_FELIZ[8] = {
    0b00111100,
    0b01000010,
    0b10100101,
    0b10000001,
    0b10100101,
    0b10011001,
    0b01000010,
    0b00111100
};

/* Letra H */
static const uint8_t PATRON_H[8] = {
    0b10000001,
    0b10000001,
    0b10000001,
    0b11111111,
    0b10000001,
    0b10000001,
    0b10000001,
    0b10000001
};

/* Flecha derecha */
static const uint8_t PATRON_FLECHA[8] = {
    0b00001000,
    0b00001100,
    0b00001110,
    0b11111111,
    0b11111111,
    0b00001110,
    0b00001100,
    0b00001000
};

static void cargar_patron(const uint8_t patron[])
{
    uint8_t i;
    for (i = 0U; i < FILAS; i++) framebuf[i] = patron[i];
}

/*
 * mostrar_patron_por_tiempo
 * --------------------------
 * Muestra un patron durante N milisegundos,
 * refrescando la matriz continuamente.
 */
static void mostrar_patron_por_tiempo(const uint8_t patron[], uint16_t ms)
{
    cargar_patron(patron);
    uint16_t ciclos = ms / (FILAS * FRAME_MS);
    uint16_t i;
    for (i = 0U; i < ciclos; i++) {
        matriz_scan();
    }
}

/*
 * efecto_lluvia
 * --------------
 * Pixeles aleatorios caen de arriba a abajo.
 * Usa un LFSR simple para pseudo-aleatoriedad sin rand().
 */
static void efecto_lluvia(uint16_t duracion_ms)
{
    uint8_t lfsr = 0xACU;   /* semilla del LFSR */
    uint16_t t;

    matriz_clear();

    for (t = 0U; t < duracion_ms / 8U; t++) {
        /* Desplazar todas las filas hacia abajo */
        uint8_t fila;
        for (fila = FILAS - 1U; fila > 0U; fila--) {
            framebuf[fila] = framebuf[fila - 1U];
        }

        /* Nueva fila de gotas en la fila 0 usando LFSR */
        lfsr = (uint8_t)((lfsr >> 1U) ^ (uint8_t)((lfsr & 1U) ? 0xB8U : 0x00U));
        framebuf[0] = lfsr;

        matriz_scan();
    }
}

int main(void)
{
    GPIO_PORT_MODE_B(0xFFU);    /* filas   = salidas */
    GPIO_PORT_MODE_D(0xFFU);    /* columnas = salidas */
    GPIO_PORT_WRITE_B(0x00U);
    GPIO_PORT_WRITE_D(0xFFU);   /* columnas en HIGH = todos apagados */

    while (1)
    {
        mostrar_patron_por_tiempo(PATRON_FELIZ,  2000U);
        mostrar_patron_por_tiempo(PATRON_H,      2000U);
        mostrar_patron_por_tiempo(PATRON_FLECHA, 2000U);
        efecto_lluvia(3000U);
    }

    return 0;
}

/*
 * -------------------------------------------------------
 * PREGUNTAS DE REFLEXION
 * -------------------------------------------------------
 * 1. Si FRAME_MS = 1 y FILAS = 8, a cuantos FPS
 *    se refresca la imagen? Por que el ojo no ve parpadeo?
 *
 * 2. Por que se invierte framebuf con ~framebuf[fila]
 *    al escribir en PORTD? Que tipo de matriz usa este circuito?
 *
 * 3. El LFSR genera numeros pseudo-aleatorios. Investiga
 *    que es un LFSR (Linear Feedback Shift Register) y
 *    por que es util en microcontroladores sin FPU.
 *
 * 4. DESAFIO: Crea una animacion de un punto que rebota
 *    en los bordes de la matriz, como el juego Pong.
 * -------------------------------------------------------
 */
