/*
 * ej_7seg_multiplex.c
 *
 * Aplicacion: Display 7 segmentos multiplexado — 4 digitos
 * Modulo HAL: gpio.h
 * Target:     ATmega328P / ATmega1284P
 *
 * Circuito:
 *   PORTD (PD0..PD6) -> segmentos a..g (compartidos entre digitos)
 *   PB0 -> anodo/catodo comun del digito 0 (unidades)
 *   PB1 -> anodo/catodo comun del digito 1 (decenas)
 *   PB2 -> anodo/catodo comun del digito 2 (centenas)
 *   PB3 -> anodo/catodo comun del digito 3 (miles)
 *   Resistencias 220 ohm en cada segmento de PORTD
 *   Transistores NPN (BC547) en PB0..PB3 para manejar
 *   la corriente de cada digito (base via 1k ohm)
 *
 * -------------------------------------------------------
 * CONCEPTO CLAVE: Multiplexado de displays
 * -------------------------------------------------------
 * Mostrar 4 digitos con solo 11 pines (7 segmentos + 4 enables)
 * en lugar de 28 (7 x 4). El truco es encender un digito
 * a la vez pero tan rapido (cada ~2ms) que el ojo los ve
 * todos encendidos simultaneamente (persistencia retiniana).
 *
 * Secuencia de refresh:
 *   1. Apagar todos los digitos (evitar ghosting)
 *   2. Cargar patron del digito activo en PORTD
 *   3. Encender solo ese digito
 *   4. Esperar ~2ms
 *   5. Repetir con el siguiente digito
 * -------------------------------------------------------
 */

#include <util/delay.h>
#include "gpio.h"

/* Patrones 7 segmentos — anodo comun (0=ON, 1=OFF) */
static const uint8_t SEG7[] = {
    0b11000000,  /* 0 */
    0b11111001,  /* 1 */
    0b10100100,  /* 2 */
    0b10110000,  /* 3 */
    0b10011001,  /* 4 */
    0b10010010,  /* 5 */
    0b10000010,  /* 6 */
    0b11111000,  /* 7 */
    0b10000000,  /* 8 */
    0b10010000,  /* 9 */
};

#define SEG7_OFF     0b11111111U
#define NUM_DIGITOS  4U
#define REFRESH_MS   2U       /* tiempo por digito: 2ms -> 125Hz total */

/*
 * Buffer de display: guarda los 4 digitos a mostrar.
 * display_buf[0] = digito de la derecha (unidades)
 * display_buf[3] = digito de la izquierda (miles)
 */
static uint8_t display_buf[NUM_DIGITOS] = {0U, 0U, 0U, 0U};

/*
 * display_set_number
 * -------------------
 * Carga un numero de 0 a 9999 en el buffer del display.
 * Lo descompone en sus 4 digitos decimales.
 */
static void display_set_number(uint16_t numero)
{
    if (numero > 9999U) numero = 9999U;

    display_buf[0] = (uint8_t)(numero % 10U);           /* unidades   */
    display_buf[1] = (uint8_t)((numero / 10U)   % 10U); /* decenas    */
    display_buf[2] = (uint8_t)((numero / 100U)  % 10U); /* centenas   */
    display_buf[3] = (uint8_t)((numero / 1000U) % 10U); /* miles      */
}

/*
 * display_refresh
 * ----------------
 * Realiza UN ciclo completo de refresh (los 4 digitos).
 * Debe llamarse continuamente en el loop principal.
 * Cada ciclo dura NUM_DIGITOS * REFRESH_MS = 8ms.
 *
 * IMPORTANTE: esta funcion es BLOQUEANTE durante 8ms.
 * En un sistema real se haria con un Timer IRQ.
 * Ver comentario al final del archivo sobre esa mejora.
 */
static void display_refresh(void)
{
    uint8_t dig;

    for (dig = 0U; dig < NUM_DIGITOS; dig++) {
        /*
         * Paso 1: apagar TODOS los enables antes de cambiar
         * los segmentos. Evita el "ghosting" (digitos fantasma
         * que aparecen brevemente con el patron del digito anterior).
         *
         * En anodo comun: enable HIGH = digito ON
         * Ponemos PB0..PB3 en LOW = todos apagados
         */
        GPIO_PORT_WRITE_B(0x00U);

        /*
         * Paso 2: cargar el patron del segmento en PORTD.
         * Lo hacemos con el display apagado para que el cambio
         * no sea visible (sin glitch).
         */
        GPIO_PORT_WRITE_D(SEG7[display_buf[dig]]);

        /*
         * Paso 3: encender SOLO el digito activo.
         * PB0 = digito 0, PB1 = digito 1, etc.
         */
        GPIO_PORT_WRITE_B((uint8_t)(1U << dig));

        /* Paso 4: mantener encendido REFRESH_MS */
        _delay_ms(REFRESH_MS);
    }

    /* Apagar al terminar el ciclo */
    GPIO_PORT_WRITE_B(0x00U);
}

int main(void)
{
    /* PORTD = segmentos (salida) */
    GPIO_PORT_MODE_D(0xFFU);
    GPIO_PORT_WRITE_D(SEG7_OFF);

    /* PB0..PB3 = enables de digitos (salida) */
    GPIO_PIN_MODE_PORTB(0, OUTPUT);
    GPIO_PIN_MODE_PORTB(1, OUTPUT);
    GPIO_PIN_MODE_PORTB(2, OUTPUT);
    GPIO_PIN_MODE_PORTB(3, OUTPUT);
    GPIO_PORT_WRITE_B(0x00U);   /* todos apagados */

    uint16_t contador = 0U;
    uint16_t refresh_count = 0U;

    while (1)
    {
        /*
         * Actualizar el display continuamente.
         * Cada llamada dura 8ms (4 digitos x 2ms).
         *
         * Para incrementar el contador cada ~1 segundo:
         * 1000ms / 8ms = 125 ciclos de refresh
         */
        display_set_number(contador);
        display_refresh();

        refresh_count++;
        if (refresh_count >= 125U) {
            refresh_count = 0U;
            contador++;
            if (contador > 9999U) {
                contador = 0U;
            }
        }
    }

    return 0;
}

/*
 * -------------------------------------------------------
 * NOTA SOBRE MEJORA CON TIMER IRQ
 * -------------------------------------------------------
 * En este ejemplo el refresh es bloqueante (_delay_ms).
 * Esto significa que el CPU no puede hacer nada mas
 * mientras refresca el display.
 *
 * La forma profesional es usar un Timer en modo CTC
 * que llame a display_refresh() cada 2ms por IRQ.
 * Asi el CPU queda libre para logica de aplicacion.
 *
 * Cuando se cubra timer.h en el curso, este ejemplo
 * se puede mejorar de esa forma.
 * -------------------------------------------------------
 *
 * PREGUNTAS DE REFLEXION
 * -------------------------------------------------------
 * 1. Que es el "ghosting" en un display multiplexado?
 *    Por que apagamos todos los enables antes de cambiar
 *    el patron de segmentos?
 *
 * 2. Si REFRESH_MS = 2ms y NUM_DIGITOS = 4, a que
 *    frecuencia se refresca cada digito individualmente?
 *    Y el display completo?
 *
 * 3. Que pasa si aumentas REFRESH_MS a 50ms?
 *    Que fenomeno visual observas y por que?
 *
 * 4. DESAFIO: Modifica el codigo para mostrar el numero
 *    en formato HH:MM (horas y minutos) con el punto
 *    decimal del digito 1 como separador de dos puntos.
 * -------------------------------------------------------
 */
