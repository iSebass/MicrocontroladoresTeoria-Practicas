/*
 * ej_secuencia_luces.c
 *
 * Aplicacion: Secuencias de luces con GPIO puro
 * Modulo HAL: gpio.h
 * Target:     ATmega328P / ATmega1284P
 *
 * Circuito:
 *   PB0..PB7 -> LEDs con resistencias de 220 ohm a GND
 *   (Puerto B completo = 8 LEDs)
 *
 * -------------------------------------------------------
 * CONCEPTO CLAVE: Puerto completo vs pin individual
 * -------------------------------------------------------
 * Cuando se controlan varios pines del mismo puerto,
 * es mas eficiente escribir el puerto completo de una vez:
 *
 *   GPIO_PORT_WRITE_B(0b00001111)  // 4 LEDs ON, 4 OFF
 *
 * En lugar de 8 llamadas individuales a GPIO_WRITE_PORTB.
 * Una sola instruccion AVR OUT reemplaza 8 instrucciones.
 * -------------------------------------------------------
 */

#include <util/delay.h>
#include "gpio.h"

/* Tiempo base de cada paso en las secuencias (ms) */
#define PASO_MS   80U

/* =========================================
   SECUENCIA 1: Semaforo vehicular
   Verde -> Amarillo -> Rojo -> Verde ...
   PB0 = Rojo | PB1 = Amarillo | PB2 = Verde
   ========================================= */
static void secuencia_semaforo(void)
{
    /* Verde: 3 segundos */
    GPIO_PORT_WRITE_B(0b00000100);   /* solo PB2 encendido */
    _delay_ms(3000);

    /* Amarillo: 1 segundo */
    GPIO_PORT_WRITE_B(0b00000010);   /* solo PB1 encendido */
    _delay_ms(1000);

    /* Rojo: 3 segundos */
    GPIO_PORT_WRITE_B(0b00000001);   /* solo PB0 encendido */
    _delay_ms(3000);
}

/* =========================================
   SECUENCIA 2: Knight Rider (KITT)
   Barrido de izquierda a derecha y vuelta
   ========================================= */
static void secuencia_knight_rider(void)
{
    uint8_t pos;

    /* Ida: PB0 -> PB7 */
    for (pos = 0U; pos < 8U; pos++) {
        GPIO_PORT_WRITE_B((uint8_t)(1U << pos));
        _delay_ms(PASO_MS);
    }

    /* Vuelta: PB7 -> PB0 */
    for (pos = 7U; pos > 0U; pos--) {
        GPIO_PORT_WRITE_B((uint8_t)(1U << pos));
        _delay_ms(PASO_MS);
    }
}

/* =========================================
   SECUENCIA 3: Binario ascendente
   Cuenta de 0 a 255 en binario con los 8 LEDs
   Util para ver como se ve un contador en hardware
   ========================================= */
static void secuencia_binario(void)
{
    uint8_t valor;
    for (valor = 0U; valor < 255U; valor++) {
        GPIO_PORT_WRITE_B(valor);
        _delay_ms(PASO_MS);
    }
    GPIO_PORT_WRITE_B(255U);
    _delay_ms(PASO_MS);
}

/* =========================================
   SECUENCIA 4: Carga (loading bar)
   Los LEDs se van encendiendo uno a uno
   y luego apagando uno a uno
   ========================================= */
static void secuencia_carga(void)
{
    uint8_t i;
    uint8_t mascara = 0U;

    /* Encender de izquierda a derecha */
    for (i = 0U; i < 8U; i++) {
        mascara |= (uint8_t)(1U << i);
        GPIO_PORT_WRITE_B(mascara);
        _delay_ms(PASO_MS * 2U);
    }

    /* Apagar de derecha a izquierda */
    for (i = 0U; i < 8U; i++) {
        mascara &= (uint8_t)(~(1U << (7U - i)));
        GPIO_PORT_WRITE_B(mascara);
        _delay_ms(PASO_MS * 2U);
    }
}

/* =========================================
   SECUENCIA 5: Ping-Pong (dos LEDs se persiguen)
   ========================================= */
static void secuencia_ping_pong(void)
{
    uint8_t pos;

    for (pos = 0U; pos < 7U; pos++) {
        /*
         * Dos LEDs encendidos: pos y pos+1
         * Se mueven juntos de izquierda a derecha
         */
        GPIO_PORT_WRITE_B((uint8_t)((1U << pos) | (1U << (pos + 1U))));
        _delay_ms(PASO_MS);
    }
    for (pos = 7U; pos > 1U; pos--) {
        GPIO_PORT_WRITE_B((uint8_t)((1U << pos) | (1U << (pos - 1U))));
        _delay_ms(PASO_MS);
    }
}

/* =========================================
   MAIN
   ========================================= */
int main(void)
{
    /*
     * Configurar todo PORTB como salida de una vez.
     * 0xFF = 11111111 = todos los pines como OUTPUT.
     * Equivale a 8 llamadas GPIO_PIN_MODE_PORTB(n, OUTPUT).
     */
    GPIO_PORT_MODE_B(0xFFU);

    /* Apagar todos los LEDs al inicio */
    GPIO_PORT_WRITE_B(0x00U);

    while (1)
    {
        secuencia_semaforo();
        secuencia_knight_rider();
        secuencia_binario();
        secuencia_carga();
        secuencia_ping_pong();
    }

    return 0;
}

/*
 * -------------------------------------------------------
 * PREGUNTAS DE REFLEXION
 * -------------------------------------------------------
 * 1. Por que se usa GPIO_PORT_WRITE_B en lugar de 8
 *    llamadas a GPIO_WRITE_PORTB? Que ventaja tiene en AVR?
 *
 * 2. En secuencia_knight_rider(), que valor tiene la
 *    expresion (1U << 3)? Dibuja el patron de bits.
 *
 * 3. Modifica secuencia_binario() para que cuente hacia
 *    atras (de 255 a 0). Que cambio minimo necesitas?
 *
 * 4. DESAFIO: Crea una secuencia "latido de corazon"
 *    donde los LEDs se encienden y apagan dos veces
 *    rapido y luego hacen una pausa larga.
 * -------------------------------------------------------
 */
