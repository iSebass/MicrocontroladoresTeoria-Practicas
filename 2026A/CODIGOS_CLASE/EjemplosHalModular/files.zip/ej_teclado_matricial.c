/*
 * ej_teclado_matricial.c
 *
 * Aplicacion: Teclado matricial 4x4
 * Modulo HAL: gpio.h
 * Target:     ATmega328P / ATmega1284P
 *
 * Circuito (teclado 4x4 estandar tipo membrana):
 *   FILAS    (salidas): PB0=F0, PB1=F1, PB2=F2, PB3=F3
 *   COLUMNAS (entradas con pull-up): PC0=C0, PC1=C1, PC2=C2, PC3=C3
 *
 * Layout del teclado:
 *       C0   C1   C2   C3
 *   F0 [ 1 ] [ 2 ] [ 3 ] [ A ]
 *   F1 [ 4 ] [ 5 ] [ 6 ] [ B ]
 *   F2 [ 7 ] [ 8 ] [ 9 ] [ C ]
 *   F3 [ * ] [ 0 ] [ # ] [ D ]
 *
 * -------------------------------------------------------
 * CONCEPTO CLAVE: Escaneo de matriz de teclado
 * -------------------------------------------------------
 * Un teclado 4x4 tiene 16 teclas pero solo 8 pines.
 * Funciona como una matriz de interruptores:
 *
 *   Tecla [fila=1][col=2] = tecla "6"
 *   Cuando se presiona, conecta la fila 1 con la columna 2.
 *
 * Para detectar que tecla esta presionada:
 *   1. Poner TODAS las filas en HIGH
 *   2. Poner la fila 0 en LOW
 *   3. Leer las columnas: si alguna lee LOW, esa tecla esta presionada
 *   4. Poner la fila 0 en HIGH, la fila 1 en LOW
 *   5. Repetir para todas las filas
 *
 * Las columnas tienen pull-up: sin tecla = HIGH, con tecla = LOW
 * -------------------------------------------------------
 */

#include <util/delay.h>
#include "gpio.h"

/* Pines de filas (salidas) */
#define FILA0_PIN   0U
#define FILA1_PIN   1U
#define FILA2_PIN   2U
#define FILA3_PIN   3U

/* Pines de columnas (entradas con pull-up) */
#define COL0_PIN    0U
#define COL1_PIN    1U
#define COL2_PIN    2U
#define COL3_PIN    3U

#define NUM_FILAS   4U
#define NUM_COLS    4U
#define DEBOUNCE_MS 20U
#define NO_KEY      0xFFU   /* ninguna tecla presionada */

/*
 * Mapa de teclas: teclado[fila][col] = caracter
 * Coincide con el layout estandar del teclado de membrana 4x4
 */
static const char KEYMAP[NUM_FILAS][NUM_COLS] = {
    { '1', '2', '3', 'A' },
    { '4', '5', '6', 'B' },
    { '7', '8', '9', 'C' },
    { '*', '0', '#', 'D' }
};

/* Pines de fila en un arreglo para iterar */
static const uint8_t FILA_PINS[NUM_FILAS] = {
    FILA0_PIN, FILA1_PIN, FILA2_PIN, FILA3_PIN
};

/* Pines de columna en un arreglo para iterar */
static const uint8_t COL_PINS[NUM_COLS] = {
    COL0_PIN, COL1_PIN, COL2_PIN, COL3_PIN
};

/*
 * teclado_init
 * -------------
 * Configura los pines del teclado.
 * Filas como salidas (las activamos una por una).
 * Columnas como entradas con pull-up interno.
 */
static void teclado_init(void)
{
    uint8_t i;

    /* Filas: salidas, todas en HIGH (inactivas) */
    for (i = 0U; i < NUM_FILAS; i++) {
        GPIO_PIN_MODE_PORTB(FILA_PINS[i], OUTPUT);
        GPIO_WRITE_PORTB(FILA_PINS[i], HIGH);
    }

    /* Columnas: entradas con pull-up */
    for (i = 0U; i < NUM_COLS; i++) {
        GPIO_PIN_MODE_PORTC(COL_PINS[i], INPUT);
        GPIO_PULLUP_PORTC(COL_PINS[i], 1U);
    }
}

/*
 * teclado_scan
 * -------------
 * Escanea el teclado y retorna el caracter de la tecla
 * presionada, o NO_KEY si ninguna esta presionada.
 *
 * Algoritmo:
 *   Para cada fila:
 *     1. Poner esa fila en LOW (activar)
 *     2. Leer todas las columnas
 *     3. Si alguna columna lee LOW -> tecla encontrada
 *     4. Poner la fila de vuelta en HIGH (desactivar)
 */
static char teclado_scan(void)
{
    uint8_t fila, col;

    for (fila = 0U; fila < NUM_FILAS; fila++) {
        /* Activar la fila actual (LOW) */
        GPIO_WRITE_PORTB(FILA_PINS[fila], LOW);

        /*
         * Pequeña espera para que la señal se estabilice.
         * Los cables del teclado actuan como capacitores
         * y necesitan tiempo para cargarse/descargarse.
         */
        _delay_us(10);

        /* Escanear las columnas */
        for (col = 0U; col < NUM_COLS; col++) {
            if (GPIO_READ_PORTC(COL_PINS[col]) == LOW) {
                /*
                 * Tecla detectada. Desactivar la fila antes de retornar
                 * para no dejar el pin en LOW indefinidamente.
                 */
                GPIO_WRITE_PORTB(FILA_PINS[fila], HIGH);
                return KEYMAP[fila][col];
            }
        }

        /* Desactivar la fila antes de pasar a la siguiente */
        GPIO_WRITE_PORTB(FILA_PINS[fila], HIGH);
    }

    return (char)NO_KEY;
}

/*
 * teclado_get_key
 * ----------------
 * Espera hasta que se presione una tecla y la retorna.
 * Incluye debounce completo:
 *   1. Esperar presion
 *   2. Confirmar con delay
 *   3. Esperar que se suelte
 */
static char teclado_get_key(void)
{
    char tecla;

    /* Esperar presion */
    do {
        tecla = teclado_scan();
    } while (tecla == (char)NO_KEY);

    /* Debounce: confirmar */
    _delay_ms(DEBOUNCE_MS);
    if (teclado_scan() == (char)NO_KEY) {
        return (char)NO_KEY;  /* fue un ruido, no una presion real */
    }

    /* Esperar que se suelte */
    while (teclado_scan() != (char)NO_KEY) {
        _delay_ms(DEBOUNCE_MS);
    }

    return tecla;
}

/* =========================================
   APLICACION: Caja de seguridad con clave
   PIN correcto: 1234
   LEDs en PB4 y PB5:
     PB4 = LED verde (acceso concedido)
     PB5 = LED rojo  (acceso denegado)
   ========================================= */
#define PIN_LONGITUD   4U
static const char PIN_SECRETO[PIN_LONGITUD] = {'1', '2', '3', '4'};

/* Buffer para mostrar en terminal (via UART, aqui simulamos con LEDs) */
static char pin_ingresado[PIN_LONGITUD];
static uint8_t pin_indice = 0U;

static void leds_ok(void)
{
    GPIO_WRITE_PORTB(4, HIGH);
    GPIO_WRITE_PORTB(5, LOW);
    _delay_ms(2000);
    GPIO_WRITE_PORTB(4, LOW);
}

static void leds_error(void)
{
    uint8_t i;
    for (i = 0U; i < 3U; i++) {
        GPIO_WRITE_PORTB(5, HIGH);
        _delay_ms(200);
        GPIO_WRITE_PORTB(5, LOW);
        _delay_ms(200);
    }
}

static uint8_t verificar_pin(void)
{
    uint8_t i;
    for (i = 0U; i < PIN_LONGITUD; i++) {
        if (pin_ingresado[i] != PIN_SECRETO[i]) return 0U;
    }
    return 1U;
}

int main(void)
{
    /* Inicializar teclado */
    teclado_init();

    /* LEDs indicadores en PB4 y PB5 */
    GPIO_PIN_MODE_PORTB(4, OUTPUT);
    GPIO_PIN_MODE_PORTB(5, OUTPUT);
    GPIO_WRITE_PORTB(4, LOW);
    GPIO_WRITE_PORTB(5, LOW);

    while (1)
    {
        char tecla = teclado_get_key();

        if (tecla == (char)NO_KEY) continue;

        if (tecla == '*') {
            /* '*' = borrar / reiniciar entrada */
            pin_indice = 0U;
            continue;
        }

        if (tecla == '#') {
            /* '#' = confirmar PIN */
            if (pin_indice == PIN_LONGITUD) {
                if (verificar_pin()) {
                    leds_ok();
                } else {
                    leds_error();
                }
            } else {
                leds_error();   /* PIN incompleto */
            }
            pin_indice = 0U;
            continue;
        }

        /* Digito normal: guardar en buffer */
        if (pin_indice < PIN_LONGITUD) {
            pin_ingresado[pin_indice] = tecla;
            pin_indice++;

            /*
             * Feedback visual: parpadeo rapido del LED rojo
             * para confirmar que se registro la tecla
             */
            GPIO_WRITE_PORTB(5, HIGH);
            _delay_ms(50);
            GPIO_WRITE_PORTB(5, LOW);
        }
    }

    return 0;
}

/*
 * -------------------------------------------------------
 * PREGUNTAS DE REFLEXION
 * -------------------------------------------------------
 * 1. Por que se activa una fila a la vez en LOW en lugar
 *    de activarlas todas a la vez? Que problema causaria
 *    activar todas simultáneamente?
 *
 * 2. Que es un "fantasma de tecla" (key ghosting) en
 *    matrices de teclado? Como se puede prevenir?
 *
 * 3. El PIN se compara caracter a caracter en verificar_pin().
 *    Que problema de seguridad tiene esta comparacion?
 *    (Pista: busca "timing attack" en criptografia.)
 *
 * 4. DESAFIO: Modifica la aplicacion para que el usuario
 *    pueda cambiar el PIN. Presionar 'A' + PIN actual +
 *    '#' + PIN nuevo + '#' para cambiar la clave.
 *    Guarda el nuevo PIN en una variable global.
 * -------------------------------------------------------
 */
