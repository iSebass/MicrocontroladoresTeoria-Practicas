/*
 * ej_7seg_unico.c
 *
 * Aplicacion: Display 7 segmentos — digito unico (0-9 y letras)
 * Modulo HAL: gpio.h
 * Target:     ATmega328P / ATmega1284P
 *
 * Circuito (display de anodo comun):
 *   PD0 -> segmento a  (arriba)
 *   PD1 -> segmento b  (arriba derecha)
 *   PD2 -> segmento c  (abajo derecha)
 *   PD3 -> segmento d  (abajo)
 *   PD4 -> segmento e  (abajo izquierda)
 *   PD5 -> segmento f  (arriba izquierda)
 *   PD6 -> segmento g  (centro)
 *   PD7 -> punto decimal (opcional)
 *   VCC del display -> 5V (anodo comun)
 *   Resistencias 220 ohm en cada segmento
 *
 * ANODO COMUN: el pin del micro en LOW enciende el segmento
 *              (la corriente fluye de VCC hacia el micro)
 *              Por eso los patrones tienen los bits invertidos.
 *
 * -------------------------------------------------------
 * CONCEPTO CLAVE: Puerto completo para datos paralelos
 * -------------------------------------------------------
 * Un display 7 segmentos necesita 7 bits simultaneos.
 * Con GPIO_PORT_WRITE_D enviamos los 7 bits de golpe,
 * lo que garantiza que todos los segmentos cambian al
 * mismo instante (sin glitches visuales).
 * -------------------------------------------------------
 *
 *   Segmentos:
 *    _
 *   |_|   a=arriba, b=der.arriba, c=der.abajo
 *   |_|   d=abajo,  e=izq.abajo,  f=izq.arriba, g=centro
 *
 */

#include <util/delay.h>
#include "gpio.h"

/*
 * Tabla de patrones para display de ANODO COMUN.
 *
 * Bit 0 = segmento a, Bit 1 = b, ..., Bit 6 = g
 * 0 = segmento ON (anodo comun: LOW enciende)
 * 1 = segmento OFF
 *
 * Bit 7 (punto decimal) = 1 por defecto (apagado)
 *
 * La tabla cubre 0-9 y letras A, b, C, d, E, F
 */
static const uint8_t SEG7_TABLA[] = {
    /*         gfedcba  */
    0b11000000,  /* 0 -> a,b,c,d,e,f ON  */
    0b11111001,  /* 1 -> b,c ON           */
    0b10100100,  /* 2 -> a,b,d,e,g ON     */
    0b10110000,  /* 3 -> a,b,c,d,g ON     */
    0b10011001,  /* 4 -> b,c,f,g ON       */
    0b10010010,  /* 5 -> a,c,d,f,g ON     */
    0b10000010,  /* 6 -> a,c,d,e,f,g ON   */
    0b11111000,  /* 7 -> a,b,c ON         */
    0b10000000,  /* 8 -> todos ON         */
    0b10010000,  /* 9 -> a,b,c,d,f,g ON   */
    0b10001000,  /* A -> a,b,c,e,f,g ON   */
    0b10000011,  /* b -> c,d,e,f,g ON     */
    0b11000110,  /* C -> a,d,e,f ON       */
    0b10100001,  /* d -> b,c,d,e,g ON     */
    0b10000110,  /* E -> a,d,e,f,g ON     */
    0b10001110,  /* F -> a,e,f,g ON       */
};

/* Numero de digitos en la tabla */
#define SEG7_COUNT   ((uint8_t)(sizeof(SEG7_TABLA) / sizeof(SEG7_TABLA[0])))

/* Patron especial: display apagado (todos los segmentos OFF) */
#define SEG7_OFF     0b11111111U

/* Patron especial: guion medio (solo segmento g) */
#define SEG7_GUION   0b10111111U

/*
 * seg7_mostrar
 * -------------
 * Muestra un digito en el display.
 * @param indice  Posicion en SEG7_TABLA (0=cero, 10=A, etc.)
 */
static void seg7_mostrar(uint8_t indice)
{
    if (indice < SEG7_COUNT) {
        GPIO_PORT_WRITE_D(SEG7_TABLA[indice]);
    }
}

/*
 * seg7_numero
 * ------------
 * Muestra un numero del 0 al 9.
 * Es un alias mas intuitivo que seg7_mostrar para digitos.
 */
static void seg7_numero(uint8_t n)
{
    if (n <= 9U) {
        GPIO_PORT_WRITE_D(SEG7_TABLA[n]);
    }
}

/*
 * seg7_apagar
 * ------------
 * Apaga todos los segmentos.
 */
static void seg7_apagar(void)
{
    GPIO_PORT_WRITE_D(SEG7_OFF);
}

int main(void)
{
    /*
     * Configurar todo PORTD como salida.
     * Los 7 segmentos + punto decimal = 8 pines.
     */
    GPIO_PORT_MODE_D(0xFFU);

    /* Apagar display al inicio */
    seg7_apagar();
    _delay_ms(500);

    while (1)
    {
        /* ── Demo 1: contar de 0 a 9 ── */
        uint8_t n;
        for (n = 0U; n <= 9U; n++) {
            seg7_numero(n);
            _delay_ms(600);
        }

        /* Pausa con guion */
        GPIO_PORT_WRITE_D(SEG7_GUION);
        _delay_ms(400);

        /* ── Demo 2: letras A-F (hexadecimal) ── */
        uint8_t letra;
        for (letra = 10U; letra < SEG7_COUNT; letra++) {
            seg7_mostrar(letra);
            _delay_ms(600);
        }

        /* Pausa con display apagado */
        seg7_apagar();
        _delay_ms(800);

        /* ── Demo 3: cuenta regresiva 9..0 ── */
        for (n = 9U; n > 0U; n--) {
            seg7_numero(n);
            _delay_ms(400);
        }
        seg7_numero(0);
        _delay_ms(400);

        /* Parpadeo del cero 3 veces */
        uint8_t i;
        for (i = 0U; i < 3U; i++) {
            seg7_apagar();
            _delay_ms(200);
            seg7_numero(0);
            _delay_ms(200);
        }
        _delay_ms(600);
    }

    return 0;
}

/*
 * -------------------------------------------------------
 * PREGUNTAS DE REFLEXION
 * -------------------------------------------------------
 * 1. Por que los patrones de la tabla tienen los bits
 *    invertidos para anodo comun? Que cambiaria si el
 *    display fuera de catodo comun?
 *
 * 2. Que representa el valor 0b10000000 en la tabla?
 *    Dibuja los segmentos encendidos.
 *
 * 3. La funcion seg7_mostrar recibe un indice, no un
 *    caracter. Como modificarias el codigo para poder
 *    llamar seg7_mostrar('A') directamente?
 *
 * 4. DESAFIO: Agrega el patron para los digitos
 *    hexadecimales b y d (minusculas, para distinguirlos
 *    de 8 y 0). Modifica la tabla y prueba con un contador
 *    hex de 0x0 a 0xF.
 * -------------------------------------------------------
 */
